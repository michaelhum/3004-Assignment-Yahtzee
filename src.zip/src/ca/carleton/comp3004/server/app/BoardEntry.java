package ca.carleton.comp3004.server.app;

/**
 * See the client board entry. Same thing.
 *
 * Created with IntelliJ IDEA.
 * Date: 23/01/15
 * Time: 9:18 PM
 */
public class BoardEntry {

    public int playerID;

    public int value;

    public BoardEntry() {
        this.playerID = -1;
        this.value = 0;
    }
}
