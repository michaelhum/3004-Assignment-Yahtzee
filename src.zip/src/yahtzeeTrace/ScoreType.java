/**
 * 
 */
package yahtzeeTrace;

/**
 * @author darryl
 *
 */
public enum ScoreType {ACES, TWOS, THREES, FOURS, FIVES, SIXES, THREEOAK, FOUROAK, FULLHOUSE, 
	SMSTRAIGHT, LGSTRAIGHT, YAHTZEE }
